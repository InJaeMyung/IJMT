This pack contains textures and materials for prototyping.

Prototype textures are very helpful to measure the scale of textures, to see the distribution of textures during uv-mapping and to visualize an idea of an early level design of a prototype game.

(C) Dexsoft